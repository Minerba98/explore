<?php

namespace Reparar;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\permission;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\plugin/Listener;
use pocketmine\plugin|TextFormat as TE;

class Main extends PluginBase implements Listener{
   public function onEnable(){
	$this->getServer()->getPluginManager()->registerEvents($this, $this);
	$this->getLogger()->info(TE::YELLOW ."Plugin Activado");
	 }
	public function onDisable(){
		$this->getLogger()->info(TE:RED ."Plugin Desactivado");
	 }
}

    public function onCommand(commandSender $Sender, Command $Command, $label, array $args){
    	switch($command->getName()}{
    	   case "reparar":
           if(!$sender->hasPermission("reparar.use")){
           	$sender->sendMessage(TE::RED ."No tienes permiso de ejecutar este comando");
           break;
           }
           
           $sender->sendMessage(TE::GREEN ."Item reparado");